const unitController=require('../controllers/unitcontroller')
const router =require('express').Router()
router.post('/create',unitController.addUnit)
router.get('/getAll',unitController.getUnit)
router.get('/get/:id',unitController.getUnitByid)
router.put('/update/:id',unitController.updateUnit)
router.delete('/delete/:id',unitController.deleteUnitByid)
module.exports=router
