const blogController=require('../controllers/blogcontroller')
const router =require('express').Router()
router.post('/create',blogController.upload,blogController.addBlog)
router.get('/getAll',blogController.getBlog)
router.get('/get/:id',blogController.getBlogByid)
router.put('/update/:id',blogController.upload,blogController.updateBlog)
router.delete('/delete/:id',blogController.deleteBlogByid)
module.exports=router
