const categoryController=require('../controllers/categorycontroller')
const router =require('express').Router()
router.post('/create',categoryController.addCategory)
router.get('/getAll',categoryController.getCategory)
router.get('/get/:id',categoryController.getCategoryByid)
router.put('/update/:id',categoryController.updateCategory)
router.delete('/delete/:id',categoryController.deleteCategoryByid)
module.exports=router
