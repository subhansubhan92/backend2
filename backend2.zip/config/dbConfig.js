const config ={
    HOST:"localhost",
    PORT:"8000",
    USER:"root",
    PASSWORD:"",
    DB:"demo",
    dialect:"mysql",
    mainURL:'http://localhost:8000/',
    pool:{
        max:5,
        min:0,
        idle:10000,
        acquire:30000
    }
};
module.exports = config;