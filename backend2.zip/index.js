const express = require("express");
const cors = require('cors');
const cookieParser = require("cookie-parser");

const app = express();  

// Middleware
app.use(cors());
app.use(express.json()); // For parsing application/json
app.use(express.urlencoded({ extended: true })); // For parsing application/x-www-form-urlencoded
app.use(cookieParser());
app.use(express.static('public'));

const unitRouter=require('./routes/unitRouter');
app.use('/api/unit',unitRouter);


const reviewRouter=require('./routes/reviewRouter');
app.use('/api/review',reviewRouter);


const categoryRouter=require('./routes/categoryRouter');
app.use('/api/category',categoryRouter);

const blogRouter=require('./routes/blogRouter');
app.use('/api/blog',blogRouter);
// For testing
app.get('/', (req, res) => {                
    res.json({ message: "Success" });
});

// Start server
const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});