const { where } = require('sequelize');
const db = require('../models');
const Category = db.category;
const addCategory = async(req,res)=>{
    try{
        const info={
            categoryName:req.body.categoryName,
            payout:req.body.payout,
           

        }
        const category=await Category.create(info)
        return res.status(200).json({
            status:"ok",
            data:category
        })
    }catch (err){
        res.status(500).json({
            error:err.message
        })
    }
}
const getCategory=async(req,res)=>{
    try{
        const category=await Category.findAll({})
        return res.status(200).json({
            status:"ok",
            data:category
        })
    }catch(err){
        res.status(500).json({
            error:err.message
        })
    }
}
const getCategoryByid=async(req,res)=>{
    try{
        const category=await Category.findOne({where:{id:req.params.id}})
        return res.status(200).json({
            status:"ok",
            data:category
        })
    }catch(err){
        res.status(500).json({
            error:err.message
        })
    }
}
const updateCategory=async(req,res)=>{
    try{
        const category=await Category.update({...req.body},{where:{id:req.params.id}})
        return res.status(200).json({
            status:"ok",
            data:category
        })
    }catch (err){
        res.status(500).json({
            error:err.message
        })
    }
}
const deleteCategoryByid=async(req,res)=>{
    try{
        const category =await Category.destroy({where:{id:req.params.id}})
        return res.status(200).json({
            status:"ok",
            data:category
        })
    }catch (err){
        res.status(500).json({
            error:err.message
        })
    }
}
module.exports={
    addCategory,
    getCategory,
    getCategoryByid,
    updateCategory,
    deleteCategoryByid
}
