const { where } = require('sequelize');
const db = require('../models');
const Unit = db.unit;
const addUnit = async(req,res)=>{
    try{
        const info={
            name:req.body.name,
            username:req.body.username,
            password:req.body.password,

        }
        const unit=await Unit.create(info)
        return res.status(200).json({
            status:"ok",
            data:unit
        })
    }catch (err){
        res.status(500).json({
            error:err.message
        })
    }
}
const getUnit=async(req,res)=>{
    try{
        const unit=await Unit.findAll({})
        return res.status(200).json({
            status:"ok",
            data:unit
        })
    }catch(err){
        res.status(500).json({
            error:err.message
        })
    }
}
const getUnitByid=async(req,res)=>{
    try{
        const unit=await Unit.findOne({where:{id:req.params.id}})
        return res.status(200).json({
            status:"ok",
            data:unit
        })
    }catch(err){
        res.status(500).json({
            error:err.message
        })
    }
}
const updateUnit=async(req,res)=>{
    try{
        const unit=await Unit.update({...req.body},{where:{id:req.params.id}})
        return res.status(200).json({
            status:"ok",
            data:unit
        })
    }catch (err){
        res.status(500).json({
            error:err.message
        })
    }
}
const deleteUnitByid=async(req,res)=>{
    try{
        const unit =await Unit.destroy({where:{id:req.params.id}})
        return res.status(200).json({
            status:"ok",
            data:unit
        })
    }catch (err){
        res.status(500).json({
            error:err.message
        })
    }
}
module.exports={
    addUnit,
    getUnit,
    getUnitByid,
    updateUnit,
    deleteUnitByid
}
