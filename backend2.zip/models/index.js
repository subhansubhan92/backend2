const { Sequelize, DataTypes } = require('sequelize');
const config = require('../config/dbConfig.js');
// const UnitModel = require('./unitModels.js');
const unitModels = require('./unitModels.js');
const CategoryModel = require('./categoryModel.js');
const reviewModel = require('./reviewModel.js');
const blogModel = require('./blogModel.js');

const sequelize = new Sequelize(
    config.DB,
    config.USER,
    config.PASSWORD, {
    host: config.HOST,
    dialect: config.dialect,
    operatorsAliases: false,
    pool: {
        max: config.pool.max,
        min: config.pool.min,
        idle: config.pool.idle,
        acquire: config.pool.acquire
    }
});

sequelize.authenticate()
    .then(() => {
        console.log('Connected to the database');
    })
    .catch((err) => {
        console.error('Unable to connect to the database:', err);
    });

const db = {
    Sequelize: Sequelize,
    sequelize: sequelize,
    unit: unitModels(sequelize, DataTypes), //Initialize the UnitModel with sequelize and DataTypes
    category: CategoryModel(sequelize, DataTypes), //Initialize the UnitModel with sequelize and DataTypes
    review:reviewModel(sequelize, DataTypes),
    blog:blogModel(sequelize, DataTypes),
};
db.sequelize.sync({force:false}).then(()=>{
    console.log("Yes Re-Sync Completed");
})
module.exports = db